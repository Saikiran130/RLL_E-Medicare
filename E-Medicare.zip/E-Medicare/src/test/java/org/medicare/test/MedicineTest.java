package org.medicare.test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.medicare.dao.MedicineRepository;
import org.medicare.entity.Medicines;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicineTest {
	@Autowired
	MedicineRepository medicinerepository;

	/*@Test
	void contextLoads() {
	}*/
	
	@Test
	public void insertMedicines() {
		Medicines M = new Medicines();
		//M.setMedicineId(105);
		M.setMedicineName("Avecold-Pd Cough Syrups");
		M.setManufactureDate("24-11-2022");
		M.setType("syrup");
		M.setPrice(110);
		M.setDescription("relief from cough");
		M.setExpdate("17-07-2025");
		M.setStatus("available");
		M.setSeller("Apollo");
		medicinerepository.save(M);
		assertNotNull(medicinerepository.findById(3).get());
	} 
	
	@Test
	public void showAllMedicines() {
		List<Medicines> list = medicinerepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	
	@Test
	public void getMedicineById() {
		Medicines M = medicinerepository.findByMedicineId(2);
		assertEquals(2, M.getMedicineId());
		
	}
	
	@Test
	public void deleteMedicine() {
		medicinerepository.deleteById(14);
		assertThat(medicinerepository.existsById(14)).isFalse();
	}
	
	@Test
	public void updateMedicine() {
		Medicines M = medicinerepository.findByMedicineId(2);
		M.setPrice(80);
		medicinerepository.save(M);
		assertNotEquals(500, medicinerepository.findByMedicineId(2).getPrice());
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}

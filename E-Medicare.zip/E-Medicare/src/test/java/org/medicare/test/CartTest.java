//package org.medicare.test;
//
//import static org.assertj.core.api.Assertions.assertThat;
//import static org.junit.jupiter.api.Assertions.*;
//import java.util.List;
//import org.junit.jupiter.api.Test;
//import org.medicare.dao.CartRepository;
//import org.medicare.entity.Cart;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//public class CartTest {
//	
//	@Autowired
//	CartRepository cartrepository;
//	
//	@Test
//	public void insertMedicines() {
//		Cart C = new Cart();
//		C.setMedicineId(1);
//		C.setMedicineName("Iodex");
//		C.setPrice(80);
//		C.setDescription("Provides relief from muscular pains");
//		cartrepository.save(C);
//		assertNotNull(cartrepository.findById(1).get());
//		System.out.println("------Insert medicine tested successfully!------");
//	} 
//	
//	@Test
//	public void showAllMedicines() {
//		List<Cart> list = cartrepository.findAll();
//		assertThat(list).size().isGreaterThan(0);
//		System.out.println("------Show all the medicines tested successfully!------");
//	}
//	
//	@Test
//	public void deleteMedicine() {
//		cartrepository.deleteById(1);
//		assertThat(cartrepository.existsById(1)).isFalse();
//		System.out.println("------Delete medicine tested successfully!------");
//	}
//	
//}
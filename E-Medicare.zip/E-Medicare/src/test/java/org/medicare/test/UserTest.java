package org.medicare.test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.medicare.dao.UserRepository;
import org.medicare.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class UserTest {
	
	@Autowired
	UserRepository userrepository;

	@Test
	public void insertUser() {
		User U = new User ();
		U.setUserId(1);
		U.setFirst_name("Aarav");
		U.setLast_name("R");
		U.setMobile_no("9966554433");
		U.setAge(26);
		U.setUsername("Aarav");
		U.setPassword("aarav@11");
		U.setGender("Male");
		userrepository.save(U);
		assertNotNull(userrepository.findById(1).get());
		System.out.println("--------Register user tested successfully!--------");
	}
	
	@Test
	public void userAuth() {
		User U = userrepository.findByUsernameAndPassword("Aarav", "aarav@11");
		assertEquals("Aarav", U.getUsername());
		assertEquals("aarav@11", U.getPassword());
		System.out.println("--------Login user tested successfully!--------");
	}	
}
export interface cart{
    medicineId:number;
    medicineName:string;
    description:string;
    price:number;
}